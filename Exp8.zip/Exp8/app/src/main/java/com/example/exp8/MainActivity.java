package com.example.exp8;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    private TextView textView;
    private LinearLayout layout;
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private Sensor proximitySensor;
    private Button btnAccelerometer, btnProximity, btnBack;
    private boolean isAccelerometerActive = false;
    private boolean isProximityActive = false; // Track if Proximity Sensor is active
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.textView);
        layout = findViewById(R.id.mainLayout);
        btnAccelerometer = findViewById(R.id.btnAccelerometer);
        btnProximity = findViewById(R.id.btnProximity);
        btnBack = findViewById(R.id.btnBack);
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        proximitySensor = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        // Handle Accelerometer Button Click
        btnAccelerometer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isAccelerometerActive = true;
                isProximityActive = false; // Deactivate proximity sensor
                if (accelerometer != null) {
                    sensorManager.registerListener(MainActivity.this, accelerometer, SensorManager.SENSOR_DELAY_UI);
                    textView.setText("Accelerometer is Active. Moving Device will show changes.");
                } else {
                    textView.setText("No Accelerometer found!");
                }
            }
        });
        // Handle Proximity Sensor Button Click
        btnProximity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isProximityActive = true;
                isAccelerometerActive = false; // Deactivate accelerometer sensor
                if (proximitySensor != null) {
                    sensorManager.registerListener(MainActivity.this, proximitySensor, SensorManager.SENSOR_DELAY_UI);
                    textView.setText("Proximity Sensor is Active. Move your hand near the device.");
                } else {
                    textView.setText("No Proximity Sensor found!");
                }
            }
        });
        // Handle Back Button Click (Clear the output)
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Clear the output when Back button is pressed
                textView.setText("Sensor Data will appear here");
                layout.setBackgroundColor(ContextCompat.getColor(MainActivity.this, android.R.color.white)); // Reset background color
                isAccelerometerActive = false;
                isProximityActive = false;
                sensorManager.unregisterListener(MainActivity.this); // Unregister all sensors
            }
        });
    }
    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER && isAccelerometerActive) {
            // Get acceleration values for each axis
            float x = event.values[0]; // X axis
            float y = event.values[1]; // Y axis
            float z = event.values[2]; // Z axis
            String acceleration = "X: " + x + " m/s²\nY: " + y + " m/s²\nZ: " + z + " m/s²";
            String motionType;
            int textColor, bgColor;
            // Simple motion type based on the absolute values of acceleration
            if (Math.abs(x) > 9.8 || Math.abs(y) > 9.8 || Math.abs(z) > 9.8) {
                motionType = "Device is in Motion!";
                textColor = ContextCompat.getColor(this, android.R.color.holo_green_dark);
                bgColor = ContextCompat.getColor(this, android.R.color.white);
            } else {
                motionType = "Device is Stable";
                textColor = ContextCompat.getColor(this, android.R.color.holo_blue_dark);
                bgColor = ContextCompat.getColor(this, android.R.color.darker_gray);
            }
            textView.setText("Acceleration:\n" + acceleration + "\nStatus: " + motionType);
            textView.setTextColor(textColor);
            layout.setBackgroundColor(bgColor); // Update background color
        } else if (event.sensor.getType() == Sensor.TYPE_PROXIMITY && isProximityActive) {
            // Read the proximity sensor value
            float proximity = event.values[0]; // Distance in cm
            String proximityMessage;
            int textColor, bgColor;
            // Check if the hand is near or away
            if (proximity < proximitySensor.getMaximumRange()) {
                proximityMessage = "Hand is Near the Device\nDistance: " + proximity + " cm";
                textColor = ContextCompat.getColor(this, android.R.color.holo_red_light);
                bgColor = ContextCompat.getColor(this, android.R.color.black);
            } else {
                proximityMessage = "Hand is Away from the Device\nDistance: " + proximity + " cm";
                textColor = ContextCompat.getColor(this, android.R.color.holo_green_light);
                bgColor = ContextCompat.getColor(this, android.R.color.white);
            }
            textView.setText(proximityMessage);
            textView.setTextColor(textColor);
            layout.setBackgroundColor(bgColor);
        }
    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}
    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this); // Unregister listeners to stop sensor events
    }
    @Override
    protected void onResume() {
        super.onResume();
        // Ensure to register the appropriate sensor based on the active mode
        if (isAccelerometerActive && accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI);
        } else if (isProximityActive && proximitySensor != null) {
            sensorManager.registerListener(this, proximitySensor, SensorManager.SENSOR_DELAY_UI);
        }
    }
}
